function string = strtrimx(string)
string = strtrim(string);
string = strrep(string,'  ','');