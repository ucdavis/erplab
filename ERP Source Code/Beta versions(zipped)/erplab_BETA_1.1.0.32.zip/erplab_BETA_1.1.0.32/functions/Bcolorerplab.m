function Bcolorerplab

c = uisetcolor([0.83 0.82 0.79],'ERPLAB Background Color') ;

erpworkingmemory('ColorB', c);