function Fcolorerplab

c = uisetcolor([0.83 0.82 0.79],'ERPLAB Foreground Color') ;
        
erpworkingmemory('ColorF', c);